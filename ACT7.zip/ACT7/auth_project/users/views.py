from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .utils import rate_limit

class LoginView(APIView):
    @rate_limit(max_requests=5, timeframe=60)  # 5 requests per 60 seconds
    def post(self, request):
        return Response({"message": "Logged in successfully"}, status=status.HTTP_200_OK)
