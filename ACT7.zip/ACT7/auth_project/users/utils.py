from functools import wraps
from django.core.cache import cache
from django.http import JsonResponse
import time

def rate_limit(max_requests, timeframe):
    """
    Limits requests per IP to `max_requests` within `timeframe` seconds.
    Returns 429 with error message if exceeded.
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(self, request, *args, **kwargs):
            ip = request.META.get('REMOTE_ADDR', '')
            key = f"rate-limit:{ip}"
            history = cache.get(key, [])

            now = time.time()
            # Filter timestamps within the allowed timeframe
            history = [timestamp for timestamp in history if now - timestamp < timeframe]

            if len(history) >= max_requests:
                return JsonResponse(
                    {
                        'error': 'Rate limit exceeded. Maximum of '
                                 f'{max_requests} requests allowed every {timeframe} seconds.'
                    },
                    status=429
                )

            # Add current timestamp and store back
            history.append(now)
            cache.set(key, history, timeout=timeframe)
            return view_func(self, request, *args, **kwargs)
        return _wrapped_view
    return decorator
